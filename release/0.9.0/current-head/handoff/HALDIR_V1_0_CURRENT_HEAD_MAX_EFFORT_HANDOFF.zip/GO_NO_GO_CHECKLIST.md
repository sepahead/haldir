# Haldir final go/no-go checklist

- [ ] HEAD and every input match the signed audit manifest.
- [ ] Reviewed tracked-file count equals tracked-file count; critical files have independent review.
- [ ] All tasks `T000`-`T125` are complete or associated claims are removed.
- [ ] No stable profile contains an experimental, permissive, dormant, or silent fallback path.
- [ ] Every claim has admissible evidence at the exact tier.
- [ ] All schemas/APIs/packages/docs/GitHub metadata agree on version and scope.
- [ ] Hostile input, resource, concurrency, restart, migration, and mixed-version campaigns pass.
- [ ] Optional Galadriel and selectable Haldir semantics remain correct.
- [ ] NCP/Engram and Crebain-internal boundaries are preserved.
- [ ] SBOM, license, vulnerability, provenance, checksums, signatures, rollback and withdrawal evidence exist.
- [ ] Independent clean-room reproduction passes.
- [ ] No P0/P1 defect or unresolved theorem/assumption contradicts a stable claim.
- [ ] Cross-repository reconciliation passes for every advertised edge.
- [ ] Release manager signs `GO`, `NARROWED_GO`, or `NO_GO`.
