# Adversarial twenty-lens standard

Every task, public statement, schema, example, proof, benchmark, and release artifact must receive all twenty reviews. `N/A` requires a falsifiable justification and lead approval.

## L01 - Claims and scope

Can a reader infer more than the exact evidence tier supports? Separate implemented, verified, validated, deployment-qualified, field-validated, and not-claimed.

Required output: defects/counterexamples, controls, tests, evidence, residual risk, and claim impact.

## L02 - First-principles semantics

Are inputs, state, transitions, outputs, invariants, units, and failure states explicit rather than implied by names?

Required output: defects/counterexamples, controls, tests, evidence, residual risk, and claim impact.

## L03 - Mathematics and statistics

Are definitions, assumptions, estimands, finite-sample behavior, multiplicity, uncertainty, calibration, and failure regions correct and explicit?

Required output: defects/counterexamples, controls, tests, evidence, residual risk, and claim impact.

## L04 - Type and state integrity

Can invalid combinations be constructed through safe APIs, deserialization, FFI, feature flags, defaults, or migration?

Required output: defects/counterexamples, controls, tests, evidence, residual risk, and claim impact.

## L05 - Time, ordering, and replay

Are clock domains, freshness, deadlines, sessions, epochs, generations, sequence numbers, duplicates, restart, and rollover unambiguous?

Required output: defects/counterexamples, controls, tests, evidence, residual risk, and claim impact.

## L06 - Identity and provenance

Can every result, command, model, dataset, scene, schema, configuration, build, and evidence artifact be traced immutably?

Required output: defects/counterexamples, controls, tests, evidence, residual risk, and claim impact.

## L07 - Authentication and cryptography

Are canonical bytes, domain separation, algorithms, identities, rotation, revocation, downgrade resistance, and failure semantics complete?

Required output: defects/counterexamples, controls, tests, evidence, residual risk, and claim impact.

## L08 - Authority and safety

Who may observe, advise, intend, authorize, publish, apply, and confirm? Can any fallback or optional component widen authority?

Required output: defects/counterexamples, controls, tests, evidence, residual risk, and claim impact.

## L09 - Hostile inputs and parsers

What happens with duplicates, unknown fields, unsafe integers, NaN/Inf, Unicode ambiguity, malformed nesting, path tricks, and contradictory metadata?

Required output: defects/counterexamples, controls, tests, evidence, residual risk, and claim impact.

## L10 - Resource and denial-of-service bounds

Are bytes, allocations, dimensions, states, queues, retries, threads, log volume, GPU/CPU work, and serialization bounded before expensive work?

Required output: defects/counterexamples, controls, tests, evidence, residual risk, and claim impact.

## L11 - Concurrency and lifecycle

Are initialization, callback ownership, races, cancellation, selected events, cleanup, crash consistency, and shutdown fully specified?

Required output: defects/counterexamples, controls, tests, evidence, residual risk, and claim impact.

## L12 - Determinism and reproducibility

Can independent clean machines reproduce code generation, builds, fixtures, simulations, proofs, benchmarks, evidence, and archives?

Required output: defects/counterexamples, controls, tests, evidence, residual risk, and claim impact.

## L13 - API, FFI, and SemVer

Is the stable surface minimal and are panic, ownership, allocation, thread safety, features, MSRV/runtime, and compatibility explicit?

Required output: defects/counterexamples, controls, tests, evidence, residual risk, and claim impact.

## L14 - Schema, wire, and language parity

Is there one normative semantic source and do all languages/encodings accept and reject the same corpus?

Required output: defects/counterexamples, controls, tests, evidence, residual risk, and claim impact.

## L15 - Configuration and deployment

Can invalid profiles start? Are paths, secrets, permissions, ACLs, certificates, environments, startup order, and rollback safe?

Required output: defects/counterexamples, controls, tests, evidence, residual risk, and claim impact.

## L16 - Observability and forensics

Can disabled, unavailable, stale, incompatible, insufficient, anomalous, denied, and internal-fault states be distinguished without leaking secrets?

Required output: defects/counterexamples, controls, tests, evidence, residual risk, and claim impact.

## L17 - Verification and evidence quality

Does each claim have the right proof: theorem, model, property, fuzz, mutation, clean-room, real-router, statistical, or physical evidence?

Required output: defects/counterexamples, controls, tests, evidence, residual risk, and claim impact.

## L18 - Ecosystem composition

Are pid-rs, NCP, Engram, Prisoma, Crebain, Galadriel, Haldir, ROS, and external authority relationships explicit and acyclic?

Required output: defects/counterexamples, controls, tests, evidence, residual risk, and claim impact.

## L19 - Human factors and governance

Are naming, docs, examples, runbooks, review roles, incident response, support, deprecation, and withdrawal usable under stress?

Required output: defects/counterexamples, controls, tests, evidence, residual risk, and claim impact.

## L20 - Counterfactual and quirky-case review

How would a malicious peer, rushed operator, odd-but-simple dataset, future maintainer, or AI-generated patch falsify the intended claim?

Required output: defects/counterexamples, controls, tests, evidence, residual risk, and claim impact.

## Required combined attacks

- valid signature plus stale epoch or wrong route;
- authenticated peer plus oversized payload and expensive logging;
- valid schema plus contradictory semantics;
- green unit tests plus divergent generated binding;
- nominal statistic plus missing lifecycle/projection evidence;
- ALLOW then crash before/after publication and restart;
- matching package version plus wrong algorithm/contract digest;
- timeout or optional-component loss plus convenience fallback;
- correct local ACL file plus wrong real router;
- synthetic success plus representative-distribution failure;
- canonical payload plus noncanonical signing bytes;
- feature unification plus privileged adapter;
- partial migration plus legacy default;
- clock rollback plus apparently valid TTL/lease;
- cancellation request plus already-selected event and duplicate effect.
