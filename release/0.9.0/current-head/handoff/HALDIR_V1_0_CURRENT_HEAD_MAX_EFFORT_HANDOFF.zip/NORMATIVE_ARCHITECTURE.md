# Haldir normative architecture rules

## Design principles

1. Fail closed or abstain explicitly; never convert absence, incompatibility, parser failure, resource exhaustion, or timeout into success.
2. Use one normative semantic source and reproducible generation for all derived schemas, bindings, fixtures, docs, and hashes.
3. Separate pure deterministic domain logic from transport, filesystem, clocks, entropy, GPU, UI, process, and deployment effects.
4. Represent identity, time, units, frame, estimand, algorithm, schema, profile, session, stream, and authority explicitly.
5. Bound memory, CPU/GPU work, dimensions, queues, retries, threads, logs, state retention, and shutdown.
6. Preserve negative results, uncertainty, abstention, and unsupported regimes rather than clamping or fallback.
7. Break pre-1.0 compatibility when necessary to remove ambiguity or insecurity; provide explicit migration and rejection.
8. Match proof/evidence type to claim type and publish exact gaps.

## Ecosystem invariants

- `pid-rs` is a transport-independent estimator library.
- NCP is mandatory for Engram external neural-service and closed-loop boundaries, not for Crebain internal communication.
- Galadriel is optional advisory infrastructure. Disabled/unavailable/stale/incompatible is not Nominal and cannot create or widen authority.
- Haldir is optional when selecting an architecture; `HaldirGate` becomes mandatory and non-bypassable once selected.
- Prisoma scientific studies must be possible from immutable captures without requiring Galadriel or Haldir.
- A PID statistic, Galadriel verdict, controller intent, Haldir authorization, published command, plant receipt, application observation, and physical effect are distinct types and evidence events.

## Dependency rule

Normative contracts -> pure core -> adapters/bindings -> applications/services -> deployment profiles -> evidence/release. Lower layers must not import project-specific authority or UI layers.
