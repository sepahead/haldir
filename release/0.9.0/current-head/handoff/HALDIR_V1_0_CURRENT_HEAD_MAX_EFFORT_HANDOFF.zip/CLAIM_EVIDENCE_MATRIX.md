# Haldir claim-to-evidence matrix

| Claim type | Minimum admissible evidence | What does not substitute |
|---|---|---|
| Pure formula/validator | independent derivation, unit/boundary/property, mutation-sensitive tests | compilation alone |
| State machine | transition table/model, arbitrary ordering, crash/restart tests | happy-path integration |
| Parser/schema | negative corpus, fuzz, differential decoders, resource caps | JSON Schema alone |
| Cryptographic/authority | vectors, threat review, real identities/routes, independent security review | valid signature or local mock alone |
| Numerical estimator | analytic/exact oracle, high precision, conditioning/error study, cross-implementation | a single fixture |
| Statistical estimator/default | preregistered development/holdout, uncertainty, bias/power/coverage/failure region | synthetic demo or in-sample tuning |
| Cross-language/wire | all required vectors and producer-consumer pairs | FFI wrappers called independent |
| Deployment/security profile | real processes/router/ACL/PKI/failure drills | config parsing or in-process bus |
| Ecosystem adapter | exact immutable producer/consumer commits and negative mixed-version tests | successful compilation |
| Field/physical claim | independent representative physical evidence and ODD | simulation or reference plant |

Evidence is rejected if inputs are mutable, source is dirty/unidentified, commands/config/seeds are missing, tuning and evaluation are mixed, failures are omitted, generated artifacts are unreproducible, or the result is not bound to the exact candidate.
