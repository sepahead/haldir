# Haldir subagent assignment template

```yaml
assignment_id: HALDIR-W##_L#-###
repository: https://github.com/sepahead/haldir
starting_commit: 9cf56e149a105026b072c9073d7e87b93103966e
lead_agent:
subagent_lane: 1|2|3
wave:
task_ids: []
required_read_paths: []
allowed_change_paths: []
prohibited_change_paths:
  - release tags and package publication
  - protected branch or repository settings
  - production credentials
  - files outside allowed_change_paths
requirements: []
ambiguities_and_counterexamples: []
commands_and_expected_outputs: []
evidence_outputs: []
resource_limits: []
return_packet:
```

Return packet must list files read/changed, assumptions, counterexamples, complete logs, evidence/checksums, unresolved risks, commits, all twenty lenses, and an explicit out-of-scope declaration.
