# Haldir current state and critical findings

## Current head

`9cf56e149a105026b072c9073d7e87b93103966e`

## Current status

Current head is an experimental inline authorization reference monitor with a narrow 0.9 non-claim/evidence package. It accepts signed typed controller intents, evaluates deployment admission, mission leases and trusted state through deterministic policy, and creates a fresh Gate-owned NCP command only on ALLOW. Current public limitations explicitly include the absence of an authenticated continuously running Gate service, a development smoke that processes zero intents and publishes zero commands, and incomplete end-to-end plant application.

## Release-blocking findings

1. No authenticated runnable Gate service currently selects the complete aggregate and authenticates provenance/delivery of caller-supplied trusted state and nonce. A typed Rust value is not a trust root.
2. The development live smoke opens/closes a fixture while processing zero intents and zero commands. It cannot support a live authorization or publication claim.
3. No packaged Gate-to-Crebain/plant runtime currently proves final-route separation, application, watchdog response, or observed physical effect end to end.
4. `haldir-ncp08` is explicitly tied to NCP 0.8 while NCP is preparing incompatible 1.0. Haldir 1.0 must migrate and requalify or remove the NCP 1.0 integration claim.
5. The TLA+ model is bounded and abstracts cryptography, I/O, clocks, durable storage, transport, and resource exhaustion. It cannot be described as a complete proof of implementation or vehicle safety.
6. Caller-supplied declaration, profile, state, challenge, and lease inputs create confused-deputy and provenance risks unless each is authenticated, freshness-bound, route-bound, and policy-scoped.
7. Cancellation success, channel closure, or local publisher construction does not prove cleanup, durable retirement, or remote ACL exclusivity.
8. ALLOW receipt, successful publication, plant receipt, application observation, and physical effect are separate events and identities.
9. HaldirGate is optional to select but mandatory and non-bypassable once selected. Runtime loss cannot activate direct publishing, cached authorization, old command, or external-authority fallback.
10. Reference-monitor correctness is not airworthiness, certification, complete vehicle safety, mission correctness, or proof of actuator behavior.

## Required disposition

Each finding receives exactly one of `FIX_AND_PROVE`, `REMOVE_FROM_1_0`, `KEEP_EXPERIMENTAL_AND_NOT_CLAIMED`, or `NO_GO`. A warning paragraph does not close a contradiction between the stable API and the evidence.
