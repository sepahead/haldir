#!/usr/bin/env python3
"""Create a machine-readable review ledger. It never claims human review."""
from __future__ import annotations
import argparse,csv,hashlib,json,mimetypes,os,re,subprocess
from pathlib import Path
TEXT_EXT={'.rs','.py','.pyi','.ts','.tsx','.js','.jsx','.mjs','.cjs','.swift','.m','.mm','.c','.cc','.cpp','.h','.hpp','.sh','.bash','.zsh','.md','.rst','.txt','.toml','.json','.yaml','.yml','.proto','.tla','.cfg','.xml','.launch','.msg','.srv','.css','.scss','.html','.lean','.lake'}
TOKENS=re.compile(r'(?i)\b(TODO|FIXME|HACK|XXX|temporary|experimental|unimplemented|unreachable|unwrap|expect|panic|unsafe|allow|deny|estop|fallback|default)\b')
p=argparse.ArgumentParser(); p.add_argument('--repo',default='.'); p.add_argument('--out',default='audit/generated'); a=p.parse_args()
repo=Path(a.repo).resolve(); out=repo/a.out; out.mkdir(parents=True,exist_ok=True)
raw=subprocess.check_output(['git','-C',str(repo),'ls-files','-z']); paths=[p.decode('utf-8','surrogateescape') for p in raw.split(b'\0') if p]
rows=[]; findings=[]
for rel in paths:
    f=repo/rel; data=f.read_bytes(); sha=hashlib.sha256(data).hexdigest(); ext=f.suffix.lower(); text=None
    if ext in TEXT_EXT or b'\0' not in data[:8192]:
        try:text=data.decode('utf-8')
        except UnicodeDecodeError: text=None
    lines=0 if text is None else text.count('\n')+(1 if text and not text.endswith('\n') else 0)
    hits=[] if text is None else [m.group(0) for m in TOKENS.finditer(text)]
    rows.append({'path':rel,'sha256':sha,'bytes':len(data),'lines':lines,'extension':ext,'text':text is not None,'generated':'UNKNOWN','public_surface':'UNKNOWN','security_critical':'UNKNOWN','science_critical':'UNKNOWN','authority_critical':'UNKNOWN','review_status':'UNREVIEWED','reviewer':'','requirements':'','defects':'','tests':'','evidence':'','disposition':''})
    if hits: findings.append({'path':rel,'token_hits':len(hits),'sample':hits[:25]})
with (out/'FILE_REVIEW_LEDGER.csv').open('w',newline='',encoding='utf-8') as h:
    w=csv.DictWriter(h,fieldnames=rows[0].keys() if rows else ['path']); w.writeheader(); w.writerows(rows)
manifest={'schema':1,'head':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'tracked_files':len(rows),'tracked_bytes':sum(r['bytes'] for r in rows),'text_lines':sum(r['lines'] for r in rows),'files':[{k:r[k] for k in ('path','sha256','bytes','lines','extension','text')} for r in rows]}
(out/'TRACKED_FILE_MANIFEST.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
(out/'SUSPICIOUS_TOKEN_INVENTORY.json').write_text(json.dumps(findings,indent=2,sort_keys=True)+'\n')
print(json.dumps({k:manifest[k] for k in ('head','tracked_files','tracked_bytes','text_lines')},sort_keys=True))
