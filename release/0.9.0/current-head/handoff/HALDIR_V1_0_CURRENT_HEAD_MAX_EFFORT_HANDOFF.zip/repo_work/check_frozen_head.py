#!/usr/bin/env python3
from pathlib import Path
import argparse, subprocess, sys
p=argparse.ArgumentParser(); p.add_argument('--expected', required=True); p.add_argument('--repo', default='.')
a=p.parse_args();
def git(*args): return subprocess.check_output(['git','-C',a.repo,*args], text=True).strip()
head=git('rev-parse','HEAD'); dirty=git('status','--porcelain=v1')
if head != a.expected:
    print(f'FROZEN_HEAD_MISMATCH expected={a.expected} actual={head}', file=sys.stderr); raise SystemExit(2)
if dirty:
    print('DIRTY_TREE\n'+dirty, file=sys.stderr); raise SystemExit(3)
print(f'FROZEN_HEAD_OK {head}')
