#!/usr/bin/env python3
from __future__ import annotations
import argparse,hashlib,json,sys
from pathlib import Path
p=argparse.ArgumentParser(); p.add_argument('manifest'); p.add_argument('--root',default='.'); a=p.parse_args(); root=Path(a.root); m=json.loads(Path(a.manifest).read_text()); errors=[]
for item in m.get('artifacts',[]):
    f=root/item['path']
    if not f.is_file(): errors.append(f"missing {item['path']}"); continue
    got=hashlib.sha256(f.read_bytes()).hexdigest()
    if got != item['sha256']: errors.append(f"digest {item['path']} expected={item['sha256']} got={got}")
if errors: print('\n'.join(errors),file=sys.stderr); raise SystemExit(2)
print(f"VERIFIED {len(m.get('artifacts',[]))} artifacts")
