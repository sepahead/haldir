#!/usr/bin/env python3
from __future__ import annotations
import argparse,csv,json
from pathlib import Path
p=argparse.ArgumentParser(); p.add_argument('ledger'); p.add_argument('--out',default='audit/generated/review-packets'); p.add_argument('--lanes',type=int,default=3); a=p.parse_args()
rows=list(csv.DictReader(open(a.ledger,encoding='utf-8'))); lanes=[{'lines':0,'files':[]} for _ in range(a.lanes)]
# Largest-first balances review load while preserving explicit file identities.
for r in sorted(rows,key=lambda x:int(x.get('lines') or 0),reverse=True):
    lane=min(lanes,key=lambda x:x['lines']); lane['files'].append(r['path']); lane['lines']+=int(r.get('lines') or 0)
out=Path(a.out); out.mkdir(parents=True,exist_ok=True)
for i,lane in enumerate(lanes,1): (out/f'lane-{i}.json').write_text(json.dumps(lane,indent=2)+'\n')
print(json.dumps({'lanes':a.lanes,'files':len(rows),'line_totals':[x['lines'] for x in lanes]}))
