#!/usr/bin/env python3
from __future__ import annotations
import argparse,json,re,subprocess
from pathlib import Path
PAT=re.compile(r'(?i)\b(safe|secure|verified|validated|production[- ]ready|field[- ]tested|exact|identical|complete|correct|real[- ]time|certified|compatible|stable|proven|guarantee)\b')
p=argparse.ArgumentParser(); p.add_argument('--repo',default='.'); p.add_argument('--out',default='audit/generated/CLAIM_LANGUAGE.json'); a=p.parse_args(); repo=Path(a.repo)
paths=subprocess.check_output(['git','-C',str(repo),'ls-files','-z','*.md','*.rst','*.txt']).split(b'\0'); findings=[]
for raw in paths:
    if not raw: continue
    rel=raw.decode(); f=repo/rel
    try: lines=f.read_text().splitlines()
    except UnicodeDecodeError: continue
    for n,line in enumerate(lines,1):
        if PAT.search(line): findings.append({'path':rel,'line':n,'text':line[:500]})
Path(a.out).parent.mkdir(parents=True,exist_ok=True); Path(a.out).write_text(json.dumps(findings,indent=2,sort_keys=True)+'\n'); print(len(findings))
