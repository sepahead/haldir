# Repository work scaffolding

Copy or integrate these reviewed utilities into `Haldir` only after adapting paths and adding repository tests. `check_frozen_head.py` and the audit scripts are directly executable. They create inventories; they do not claim human review.
