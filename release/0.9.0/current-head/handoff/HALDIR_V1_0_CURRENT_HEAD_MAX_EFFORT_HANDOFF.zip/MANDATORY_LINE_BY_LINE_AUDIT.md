# Haldir mandatory exact-checkout line-by-line audit

## Honesty and entry rule

This handoff is source-informed from the public current head but does not falsely certify a full local clone review. The implementation lead must perform the authoritative review on the exact checkout. Release is NO-GO until reviewed tracked-file count equals tracked-file count, generated artifacts have reproducible generators, and every critical file has independent review.

The first command is `git rev-parse HEAD`. If it differs from the frozen audit commit, STOP. Record the new commit and a complete diff from the frozen commit, rerun the baseline and file inventory, update every affected requirement, and obtain lead approval before applying this handoff. Never silently run current-head instructions against a later tree.

## Required commands

```bash
python repo_work/check_frozen_head.py --expected 9cf56e149a105026b072c9073d7e87b93103966e
python repo_work/audit_tracked_files.py --repo . --out audit/generated
python repo_work/make_review_packets.py audit/generated/FILE_REVIEW_LEDGER.csv --lanes 3
python repo_work/scan_claim_language.py --repo . --out audit/generated/CLAIM_LANGUAGE.json
```

## Required ledger columns

`path, git_blob_id, sha256, bytes, lines, language, generated, generator, public_surface, security_critical, science_critical, authority_critical, reviewer, review_status, requirements, assumptions, defects, tests, evidence, disposition, completed_at`.

No wildcard or directory-level statement counts as review. Generated files and their generators are separate review items. Binary/model/data assets require format, provenance, license, parser, size, integrity, and claim review.

## Path map

| Scope | Languages/format | Required focus |
|---|---|---|
| `README.md, AGENTS.md, Cargo.toml, Cargo.lock, rust-toolchain.toml, deny.toml, SECURITY.md, CHANGELOG.md` | md/toml | Authority graph, profiles, nonclaims, versions, features, TCB, commands, dependencies, and release truth. |
| `crates/haldir-contracts/**, contracts/vectors/**` | rust/json | Objects, strict parsing, canonical signing bytes, version/schema/profile identities, negative vectors, migration, and generated parity. |
| `crates/haldir-crypto/**` | rust | Algorithms, domain separation, canonical bytes, key roles, constant-time behavior, zeroization, rotation, revocation, compromise, and vectors. |
| `crates/haldir-admission/**` | rust | Deployment admission, controller identity, exact routes, challenges, freshness, scope, revocation, and confused deputy resistance. |
| `crates/haldir-core/**` | rust | TCB boundary, capability ownership, errors, no I/O, invalid-state elimination, deterministic behavior, panic/resource limits, and public API. |
| `crates/haldir-range/**` | rust | Units, intervals, inclusive/exclusive endpoints, exact arithmetic, overflow, non-finites, clamping, and non-widening. |
| `crates/haldir-state/**` | rust | State provenance, sessions/generations/epochs/sequences, replay, transitions, restart, lifecycle, model correspondence, and freshness. |
| `crates/haldir-policy-native/**` | rust | Normative tables, default deny, HOLD/ESTOP, composition, state freshness, constraints, monotonic non-widening, and exhaustive cases. |
| `crates/haldir-gate/**` | rust | Typestate, activation, ingress, decision, Gate-owned command creation, receipts, publisher capability, continuously running service, cancellation, and shutdown. |
| `crates/haldir-durable/**` | rust | Journal format, atomicity/fsync assumptions, corruption, rollback, command/receipt crash points, restart high-water, and audit recovery. |
| `crates/haldir-deployment/**` | rust | Complete config before side effects, profiles, paths, permissions, secrets, capability minting, startup order, rollback, and render parity. |
| `crates/haldir-ncp08/**, docs/NCP-COMPATIBILITY.md` | rust/md | Explicit 0.8 semantics, final 1.0 migration, command modes/TTL/ESTOP, sessions, canonical JSON, vectors, and no implicit upgrade. |
| `crates/haldir-transport-zenoh/**` | rust | Ingress and final routes, session lineage, queue bounds, callbacks, reconnect, cancellation, publisher exclusivity, remote identity, and real-router tests. |
| `crates/haldir-reference-plant/**` | rust | Reference-only dynamics/application, watchdog, HOLD/ESTOP, receipts, application observation, profile scope, and no general vehicle claim. |
| `crates/haldir-evidence/**, evidence/**` | rust/json/md | Claim vocabulary, evidence tiers, generation, signatures/checksums, immutable inputs, no synthetic/live substitution, and clean reproduction. |
| `formal/HaldirAuthority.tla, formal/HaldirAuthority.cfg, formal/README.md` | tla/cfg/md | Invariants, bounds, fairness, crash/order cases, lease expiry, rollover, optional advisory, TLC results, assumptions, and refinement. |
| `deploy/secure-reference-v1/**` | yaml/json/certs/scripts | PKI roles, key custody, ACL least privilege, final-route deny tests, router/process identities, rotation/revocation, and reproducible campaign. |
| `docs/**, release/0.9.0/**` | md/json | Authority graph, assurance profiles, claim/evidence ledger, nonclaims, project catalog, research protocol, roadmap, and exact status. |
| `tools/**, .github/**, justfile` | rust/python/shell/yaml | Locked formal/CI/release commands, permissions, artifacts, fuzz/mutation, reproducible vectors, packages, and publication. |

## Per-line questions

1. What assumption does this statement make, and where is it enforced?
2. Can it execute on untrusted, stale, replayed, malformed, non-finite, oversized, or partially initialized input?
3. What unit, frame, clock, identity, version, estimand, authority, and resource bound applies?
4. What happens if this line and each following operation fail?
5. Can the behavior differ by platform, feature, language binding, concurrency schedule, or generated artifact?
6. What test would fail if the statement were wrong?
7. Does any documentation or evidence overstate it?
8. Could a simple but unusual input evade cases learned from common code/examples?

## Zero-tolerance completion checks

- no unclassified tracked file;
- no generated artifact without a reproducible source;
- no critical line without requirement/test/evidence linkage;
- no unresolved TODO/HACK/experimental path in a stable profile;
- no self-authored evidence accepted as independent without explicit limitation;
- no later commit processed under the frozen manifest without re-audit.
