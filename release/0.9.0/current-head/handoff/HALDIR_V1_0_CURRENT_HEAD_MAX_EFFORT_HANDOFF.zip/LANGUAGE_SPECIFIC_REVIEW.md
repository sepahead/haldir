# Language-specific review requirements

## Markdown and prose

- Verify every version, date, status, command, number, citation, compatibility statement, support claim, and limitation against current code/evidence.
- Search for safe, secure, exact, verified, validated, production, real-time, complete, field-tested, compatible, stable, and certified; require a claim-ledger ID.
- Execute every command and example from a clean checkout; dead links and stale screenshots are release defects.
- Distinguish definition validity, implementation correctness, numerical accuracy, estimator validity, integration validity, and application validity.

## Rust

- Review unsafe/FFI, unwrap/expect/panic/todo/unreachable, indexing, integer casts, float comparison, overflow, allocation, recursion, and feature-gated paths.
- Review serde defaults/flatten/untagged/unknown fields, non_exhaustive types, canonicalization, Clone semantics, Send/Sync, locks, cancellation, and async blocking.
- For numerical code, derive formulas independently; check dimensions, units, conditioning, ties, zero probabilities, log domains, cancellation, summation order, and error bounds.
- For resource preflight, prove estimates dominate actual allocations and work on every branch, including reports, clones, serialization, errors, and parallel workers.

## Python

- Review typing, NumPy shape/dtype/broadcasting, non-finite handling, seeds/RNG isolation, multiprocessing, subprocess quoting, pickle/YAML loading, paths, and exception scope.
- Do not accept Python as an independent oracle when it calls the Rust implementation through FFI; label binding evidence separately.
- Pin environments and save raw inputs/outputs; reject notebook-only or manually edited evidence.

## TypeScript and JavaScript

- Review any/unknown casts, Number versus BigInt, promise rejection, React effect cleanup, workers, event listeners, timers, stale closures, structured clone, and JSON validation.
- Prove development-only adapters are absent from packaged dependency graphs and privileged commands cannot be reached by UI convenience paths.
- Check coordinate systems, image orientation/color, frame identity, timestamps, stale overlays, and resource disposal.

## Swift, Objective-C, C, and C++

- Review ABI, layout, alignment, nullability, lengths, ownership, ARC/autorelease, thread confinement, exception/panic boundaries, callbacks, and error translation.
- Validate model/tensor metadata before native calls; test missing frameworks, incompatible models, GPU reset, and partial initialization.

## Shell and Bash

- Require set -euo pipefail where appropriate, safe IFS, quoted expansions, mktemp, traps, deterministic locale/timezone, no eval, no secret echo, and explicit tool versions.
- Test paths containing spaces/newlines/dashes, partial command failure, dirty trees, existing outputs, and interrupted publication.

## JSON, YAML, TOML, Proto, schemas, and configuration

- Reject duplicate keys before schema validation, unsafe integers, non-finite values, ambiguous defaults, unknown required semantics, and noncanonical set ordering.
- Prove generated artifacts match their normative source and are reproducible; reserve removed proto fields/names.

## Formal specifications

- State abstraction boundaries and environment assumptions. Bounded model checking does not imply unbounded correctness.
- Archive tool versions, commands, full results, explored bounds, invariants, counterexamples, and implementation-refinement evidence.
