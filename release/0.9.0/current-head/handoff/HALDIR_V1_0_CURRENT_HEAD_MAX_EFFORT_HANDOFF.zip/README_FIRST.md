# Haldir 1.0 current-head implementation handoff

## Frozen audit cut

- Repository: `https://github.com/sepahead/haldir`
- Commit: `9cf56e149a105026b072c9073d7e87b93103966e`
- Prepared: `2026-07-14`
- Target: `1.0.0`
- Initial release decision: **NO-GO pending execution and independent evidence**

The first command is `git rev-parse HEAD`. If it differs from the frozen audit commit, STOP. Record the new commit and a complete diff from the frozen commit, rerun the baseline and file inventory, update every affected requirement, and obtain lead approval before applying this handoff. Never silently run current-head instructions against a later tree.

## Use

One lead agent owns the repository. It may run no more than three concurrent subagents in isolated worktrees and ordered waves. The lead reviews every returned line, reruns tests independently, resolves semantic conflicts, updates evidence, and alone integrates, signs, tags, or publishes.

This package is standalone. It contains only current final instructions, schemas, executable audit/verification scaffolding, and evidence templates; no earlier handoff is embedded.

## Files

- `README_FIRST.md`
- `CURRENT_AUDIT_CUT.json`
- `CURRENT_STATE_AND_CRITICAL_FINDINGS.md`
- `MANDATORY_LINE_BY_LINE_AUDIT.md`
- `LANGUAGE_SPECIFIC_REVIEW.md`
- `ADVERSARIAL_20_LENS_STANDARD.md`
- `NORMATIVE_ARCHITECTURE.md`
- `THREAT_MISUSE_FAILURE_MODEL.md`
- `MASTER_TASK_LEDGER.yaml`
- `WAVE_EXECUTION_PLAN.md`
- `SUBAGENT_ASSIGNMENT_TEMPLATE.md`
- `CLAIM_EVIDENCE_MATRIX.md`
- `GO_NO_GO_CHECKLIST.md`
- `RELEASE_MANIFEST_TEMPLATE.json`
- `LOCAL_CONVERGENCE_SCHEMA.json`
- `PACKAGE_VALIDATION_REPORT.md`
- `SHA256SUMS.txt`

## Task count

`T000` through `T125`. Tasks are blocking unless the associated public claim is removed.
