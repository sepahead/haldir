# Haldir threat, misuse, and failure model

## Actors

Unauthenticated peer; authenticated unauthorized peer; compromised authorized producer/controller; malicious asset/model/dataset/configuration; buggy language binding; rushed operator; future maintainer; AI-generated patch; dependency/build compromise; clock/filesystem/network/GPU/process fault; researcher overinterpreting narrow evidence.

## Mandatory threat record

`threat_id, asset_or_claim, actor, preconditions, sequence, trust_boundary, observable_symptoms, worst_consequence, preventive_controls, detective_controls, recovery, tests, evidence, residual_risk, claim_impact, owner`.

## Repository-specific starting threats

- No authenticated runnable Gate service currently selects the complete aggregate and authenticates provenance/delivery of caller-supplied trusted state and nonce. A typed Rust value is not a trust root.
- The development live smoke opens/closes a fixture while processing zero intents and zero commands. It cannot support a live authorization or publication claim.
- No packaged Gate-to-Crebain/plant runtime currently proves final-route separation, application, watchdog response, or observed physical effect end to end.
- `haldir-ncp08` is explicitly tied to NCP 0.8 while NCP is preparing incompatible 1.0. Haldir 1.0 must migrate and requalify or remove the NCP 1.0 integration claim.
- The TLA+ model is bounded and abstracts cryptography, I/O, clocks, durable storage, transport, and resource exhaustion. It cannot be described as a complete proof of implementation or vehicle safety.
- Caller-supplied declaration, profile, state, challenge, and lease inputs create confused-deputy and provenance risks unless each is authenticated, freshness-bound, route-bound, and policy-scoped.
- Cancellation success, channel closure, or local publisher construction does not prove cleanup, durable retirement, or remote ACL exclusivity.
- ALLOW receipt, successful publication, plant receipt, application observation, and physical effect are separate events and identities.
- HaldirGate is optional to select but mandatory and non-bypassable once selected. Runtime loss cannot activate direct publishing, cached authorization, old command, or external-authority fallback.
- Reference-monitor correctness is not airworthiness, certification, complete vehicle safety, mission correctness, or proof of actuator behavior.

## Misuse-resistant interface rule

Every dangerous feature needs a correct example, a deliberately wrong example, the exact refusal/error, what it does not prove, the evidence tier, and the invariant/test link. Documentation warnings do not substitute for an API that can prevent misuse.
