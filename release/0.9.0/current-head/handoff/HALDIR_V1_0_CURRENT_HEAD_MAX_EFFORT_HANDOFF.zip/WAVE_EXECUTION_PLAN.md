# Haldir one-lead, three-subagent wave plan

One lead owns the repository. Maximum concurrent subagents: three. Subagents use isolated worktrees, cannot merge/tag/publish/change protected settings or real credentials, and return a complete evidence packet. The lead reviews every line and reruns all decisive commands.

## Wave 0

Tasks `T000` through `T012`.

### Lane 1

Assigned tasks: T000, T003, T006, T009, T012

### Lane 2

Assigned tasks: T001, T004, T007, T010

### Lane 3

Assigned tasks: T002, T005, T008, T011

### Lead checkpoint

1. Inspect each branch without merging and verify starting commit/scope.
2. Reject incomplete file-review, counterexample, test, log, evidence, or lens packets.
3. Integrate in a documented deterministic order; semantic conflicts are decided from normative requirements, not convenience.
4. Run impacted tests after each integration and the full wave gate afterward.
5. Update file, defect, claim, requirement, evidence, migration, and cross-repository ledgers.
6. Record `WAVE_ACCEPTED`, `WAVE_REWORK`, or `CLAIM_REMOVED`; later waves cannot merge before acceptance.

## Wave 1

Tasks `T013` through `T025`.

### Lane 1

Assigned tasks: T015, T018, T021, T024

### Lane 2

Assigned tasks: T013, T016, T019, T022, T025

### Lane 3

Assigned tasks: T014, T017, T020, T023

### Lead checkpoint

1. Inspect each branch without merging and verify starting commit/scope.
2. Reject incomplete file-review, counterexample, test, log, evidence, or lens packets.
3. Integrate in a documented deterministic order; semantic conflicts are decided from normative requirements, not convenience.
4. Run impacted tests after each integration and the full wave gate afterward.
5. Update file, defect, claim, requirement, evidence, migration, and cross-repository ledgers.
6. Record `WAVE_ACCEPTED`, `WAVE_REWORK`, or `CLAIM_REMOVED`; later waves cannot merge before acceptance.

## Wave 2

Tasks `T026` through `T038`.

### Lane 1

Assigned tasks: T027, T030, T033, T036

### Lane 2

Assigned tasks: T028, T031, T034, T037

### Lane 3

Assigned tasks: T026, T029, T032, T035, T038

### Lead checkpoint

1. Inspect each branch without merging and verify starting commit/scope.
2. Reject incomplete file-review, counterexample, test, log, evidence, or lens packets.
3. Integrate in a documented deterministic order; semantic conflicts are decided from normative requirements, not convenience.
4. Run impacted tests after each integration and the full wave gate afterward.
5. Update file, defect, claim, requirement, evidence, migration, and cross-repository ledgers.
6. Record `WAVE_ACCEPTED`, `WAVE_REWORK`, or `CLAIM_REMOVED`; later waves cannot merge before acceptance.

## Wave 3

Tasks `T039` through `T051`.

### Lane 1

Assigned tasks: T039, T042, T045, T048, T051

### Lane 2

Assigned tasks: T040, T043, T046, T049

### Lane 3

Assigned tasks: T041, T044, T047, T050

### Lead checkpoint

1. Inspect each branch without merging and verify starting commit/scope.
2. Reject incomplete file-review, counterexample, test, log, evidence, or lens packets.
3. Integrate in a documented deterministic order; semantic conflicts are decided from normative requirements, not convenience.
4. Run impacted tests after each integration and the full wave gate afterward.
5. Update file, defect, claim, requirement, evidence, migration, and cross-repository ledgers.
6. Record `WAVE_ACCEPTED`, `WAVE_REWORK`, or `CLAIM_REMOVED`; later waves cannot merge before acceptance.

## Wave 4

Tasks `T052` through `T064`.

### Lane 1

Assigned tasks: T054, T057, T060, T063

### Lane 2

Assigned tasks: T052, T055, T058, T061, T064

### Lane 3

Assigned tasks: T053, T056, T059, T062

### Lead checkpoint

1. Inspect each branch without merging and verify starting commit/scope.
2. Reject incomplete file-review, counterexample, test, log, evidence, or lens packets.
3. Integrate in a documented deterministic order; semantic conflicts are decided from normative requirements, not convenience.
4. Run impacted tests after each integration and the full wave gate afterward.
5. Update file, defect, claim, requirement, evidence, migration, and cross-repository ledgers.
6. Record `WAVE_ACCEPTED`, `WAVE_REWORK`, or `CLAIM_REMOVED`; later waves cannot merge before acceptance.

## Wave 5

Tasks `T065` through `T077`.

### Lane 1

Assigned tasks: T066, T069, T072, T075

### Lane 2

Assigned tasks: T067, T070, T073, T076

### Lane 3

Assigned tasks: T065, T068, T071, T074, T077

### Lead checkpoint

1. Inspect each branch without merging and verify starting commit/scope.
2. Reject incomplete file-review, counterexample, test, log, evidence, or lens packets.
3. Integrate in a documented deterministic order; semantic conflicts are decided from normative requirements, not convenience.
4. Run impacted tests after each integration and the full wave gate afterward.
5. Update file, defect, claim, requirement, evidence, migration, and cross-repository ledgers.
6. Record `WAVE_ACCEPTED`, `WAVE_REWORK`, or `CLAIM_REMOVED`; later waves cannot merge before acceptance.

## Wave 6

Tasks `T078` through `T090`.

### Lane 1

Assigned tasks: T078, T081, T084, T087, T090

### Lane 2

Assigned tasks: T079, T082, T085, T088

### Lane 3

Assigned tasks: T080, T083, T086, T089

### Lead checkpoint

1. Inspect each branch without merging and verify starting commit/scope.
2. Reject incomplete file-review, counterexample, test, log, evidence, or lens packets.
3. Integrate in a documented deterministic order; semantic conflicts are decided from normative requirements, not convenience.
4. Run impacted tests after each integration and the full wave gate afterward.
5. Update file, defect, claim, requirement, evidence, migration, and cross-repository ledgers.
6. Record `WAVE_ACCEPTED`, `WAVE_REWORK`, or `CLAIM_REMOVED`; later waves cannot merge before acceptance.

## Wave 7

Tasks `T091` through `T103`.

### Lane 1

Assigned tasks: T093, T096, T099, T102

### Lane 2

Assigned tasks: T091, T094, T097, T100, T103

### Lane 3

Assigned tasks: T092, T095, T098, T101

### Lead checkpoint

1. Inspect each branch without merging and verify starting commit/scope.
2. Reject incomplete file-review, counterexample, test, log, evidence, or lens packets.
3. Integrate in a documented deterministic order; semantic conflicts are decided from normative requirements, not convenience.
4. Run impacted tests after each integration and the full wave gate afterward.
5. Update file, defect, claim, requirement, evidence, migration, and cross-repository ledgers.
6. Record `WAVE_ACCEPTED`, `WAVE_REWORK`, or `CLAIM_REMOVED`; later waves cannot merge before acceptance.

## Wave 8

Tasks `T104` through `T116`.

### Lane 1

Assigned tasks: T105, T108, T111, T114

### Lane 2

Assigned tasks: T106, T109, T112, T115

### Lane 3

Assigned tasks: T104, T107, T110, T113, T116

### Lead checkpoint

1. Inspect each branch without merging and verify starting commit/scope.
2. Reject incomplete file-review, counterexample, test, log, evidence, or lens packets.
3. Integrate in a documented deterministic order; semantic conflicts are decided from normative requirements, not convenience.
4. Run impacted tests after each integration and the full wave gate afterward.
5. Update file, defect, claim, requirement, evidence, migration, and cross-repository ledgers.
6. Record `WAVE_ACCEPTED`, `WAVE_REWORK`, or `CLAIM_REMOVED`; later waves cannot merge before acceptance.

## Wave 9

Tasks `T117` through `T125`.

### Lane 1

Assigned tasks: T117, T120, T123

### Lane 2

Assigned tasks: T118, T121, T124

### Lane 3

Assigned tasks: T119, T122, T125

### Lead checkpoint

1. Inspect each branch without merging and verify starting commit/scope.
2. Reject incomplete file-review, counterexample, test, log, evidence, or lens packets.
3. Integrate in a documented deterministic order; semantic conflicts are decided from normative requirements, not convenience.
4. Run impacted tests after each integration and the full wave gate afterward.
5. Update file, defect, claim, requirement, evidence, migration, and cross-repository ledgers.
6. Record `WAVE_ACCEPTED`, `WAVE_REWORK`, or `CLAIM_REMOVED`; later waves cannot merge before acceptance.
