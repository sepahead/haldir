# Sepahead 1.0 final cross-repository reconciliation

Start only after all five local convergence manifests validate. One cross-repository lead may run at most three concurrent subagents. Every affected repository lead retains approval authority. This package may change only exact pins, contracts, schemas, thin adapters, tests, migrations, evidence, and truthful public documentation.

- `README_FIRST.md`
- `CURRENT_HEADS.json`
- `CROSS_REPO_TASK_LEDGER.yaml`
- `COMPATIBILITY_MATRIX_TEMPLATE.csv`
- `CONTRACT_IDENTITY_SCHEMA.json`
- `CHANGE_REQUEST_TEMPLATE.md`
- `ADVERSARIAL_CAMPAIGN.md`
- `RELEASE_ORDER_AND_ROLLBACK.md`
- `GO_NO_GO_CHECKLIST.md`
- `FINAL_MANIFEST_TEMPLATE.json`
- `VALIDATION_REPORT.md`
- `SHA256SUMS.txt`
