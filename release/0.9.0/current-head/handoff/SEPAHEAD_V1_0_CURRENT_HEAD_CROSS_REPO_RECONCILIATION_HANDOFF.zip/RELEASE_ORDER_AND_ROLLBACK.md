# Coordinated release order and rollback

1. Freeze and independently qualify pid-rs and NCP foundations; they may publish independently because pid-rs does not depend on NCP.
2. Verify actual registry/source artifacts and full hashes.
3. Update Galadriel exact pid-rs/NCP pins and Haldir exact NCP pin through approved change requests; rerun all local and cross gates.
4. Publish Galadriel/Haldir only after verified foundation artifacts are consumed.
5. Update and qualify Crebain adapters and downstream Prisoma/Engram pins.
6. Run fresh post-publication campaigns.

Rollback in reverse dependency order. Never reuse versions, epochs, generations, sequences, leases, commands, receipts, keys, certificates, or withdrawn artifact identities. Preserve failed evidence and prove withdrawn artifacts are rejected.
