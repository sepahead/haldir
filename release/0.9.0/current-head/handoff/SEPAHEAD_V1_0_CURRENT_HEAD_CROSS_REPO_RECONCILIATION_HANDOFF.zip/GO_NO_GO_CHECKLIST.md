# Cross-repository go/no-go

- [ ] Five local convergence manifests validate.
- [ ] Full contract/algorithm/schema identities agree.
- [ ] Mixed versions reject unless explicitly qualified.
- [ ] Engram external NCP profile passes.
- [ ] pid-rs remains transport-independent.
- [ ] Crebain internal communication remains non-NCP.
- [ ] Galadriel is optional/advisory and failure-neutral to baseline authority.
- [ ] HaldirGate is non-bypassable.
- [ ] Positive/negative vectors, real-router, restart/replay/clock/cert/resource, scientific, and end-to-end campaigns pass.
- [ ] Independent reviews and clean-room reproductions pass.
- [ ] Public metadata is consistent.
- [ ] No P0/P1 defect remains.
- [ ] Every affected lead signs.
