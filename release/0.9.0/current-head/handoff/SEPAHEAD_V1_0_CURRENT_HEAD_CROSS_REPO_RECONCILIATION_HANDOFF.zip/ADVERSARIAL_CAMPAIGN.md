# Cross-repository adversarial campaign

Every edge requires exact-version success; old/new and new/old rejection unless qualified; wrong full hash; duplicate/unknown/unsafe fields; wrong session/epoch/sequence; duplicate/reorder/replay; wrong identity/route/plane; stale TTL/lease/heartbeat; absent optional Galadriel; unavailable HaldirGate; unauthorized publisher; payload/queue maxima; restart/rollback; clock jump; certificate rotation/expiry; generated-language parity; clean package install; public example execution; and retained raw evidence.
