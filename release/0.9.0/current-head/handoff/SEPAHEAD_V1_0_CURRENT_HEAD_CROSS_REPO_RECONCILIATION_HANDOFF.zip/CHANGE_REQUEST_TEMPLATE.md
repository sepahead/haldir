# Cross-repository change request

- ID:
- initiating and affected leads:
- local convergence commits:
- contradiction/incompatibility:
- protected invariants:
- candidate solutions and counterexamples:
- chosen solution:
- allowed files per repository:
- generated artifacts:
- version/migration impact:
- tests/evidence:
- rollback:
- approvals and integration order:
- disposition:
